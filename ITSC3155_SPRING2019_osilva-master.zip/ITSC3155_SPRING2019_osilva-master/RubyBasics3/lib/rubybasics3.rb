# Ruby Basics Part 3

class BookInStock
# YOUR CODE HERE
end