# Ruby Basics Part 3

 
    
class BookInStock
# YOUR CODE HERE

attr_accessor:isbn
    attr_accessor:price
    
def initialize (isbn,price)
        raise ArgumentError, 'isbn is empty' unless isbn.eql?('') == false
        raise ArgumentError, 'invalid price' unless price > 0.0
        
        @isbn =isbn
        @price =price
    end
    
    def price_as_string
        return "$%.2f" % price
    end

  
    
    

end