# RubyHashes
# Part I
def array_2_hash emails, contacts
    # YOUR CODE HERE
    contactsNew = {}
    i=0
    if emails [0] == nil
        return contacts 
    else
        contacts.each do |key, value|
            keyNew = :"#{key}"
            contactsNew[keyNew] = emails[i]
            i+=1
        end
    end
    return contactsNew
    
end

# Part II
def array2d_2_hash contact_info, contacts
    # YOUR CODE HERE
   contactsTemp2 = {}
   counter2 = 0
   
   if contact_info[0][0] == nil
       return contacts
   else
       contacts.each do |key, value|
           
           key2 = :"#{key}"
           contactsTemp2[key2] = {:email => contact_info[counter2][0], :phone => contact_info[counter2][1]}
           
           counter2 += 1
       end
   end
   
   
   return contactsTemp2
        
end

# Part III
def hash_2_array contacts
    # YOUR CODE HERE
    finalArray = []
    emailArray = []
    phoneArray = []
    nameArray = []
    
    contacts.each do |key, value|
        keyNew = :"#{key}"
        emailArray << contacts[keyNew][:email]
        phoneArray << contacts[keyNew][:phone]
        nameArray << "#{key}"
    end
    
    finalArray << emailArray
    finalArray << phoneArray
    finalArray << nameArray
    return finalArray
        
end
